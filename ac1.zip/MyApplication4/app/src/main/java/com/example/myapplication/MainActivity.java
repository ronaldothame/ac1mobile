package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button startButton, resetButton;
    private ScrollView scrollView;
    private TextView pergunta1TextView, pergunta2TextView, pergunta3TextView;
    private RadioGroup respostaGroup1, respostaGroup2, respostaGroup3;
    private RadioButton[] radioButtons1, radioButtons2, radioButtons3;

    private String[] perguntas = {
            "Conhecimentos Gerais: \nO animal já extinto chamado \"DODÔ\", era:",
            "Conhecimentos Gerais: \nUma dessas afirmações está \"ERRADA\".",
            "Conhecimentos Gerais: \nComplete a frase a seguir: \"De Grão em grão...\""
    };

    private String[][] respostas = {
            {"Um peixe que media até 3 metros de comprimento", "Um dinossauro", "Um pássaro", "Uma serpente marinha que se alimentava exclusivamente de algas", "Um réptil"},
            {"A lua é o satélite natural da terra", "O Jacaré é um réptil", "O Mamute era um anfíbio", "A árvore símbolo que deu nome ao nosso país é o Pau Brasil", "A piranha é um peixe de água doce"},
            {"O pintinho vai ficando gordo", "O Depósito fica cheio", "A galinha enche o papo", "O galo fica maior", "A galinha fica mais gorda"}
    };

    private int[] respostasCorretas = {2, 2, 2}; // Índices das respostas corretas para cada pergunta

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startButton = findViewById(R.id.startButton);
        resetButton = findViewById(R.id.reset);
        scrollView = findViewById(R.id.scrollView2);

        pergunta1TextView = findViewById(R.id.pergunta1);
        pergunta2TextView = findViewById(R.id.pergunta2);
        pergunta3TextView = findViewById(R.id.pergunta3);

        respostaGroup1 = findViewById(R.id.respostaGroup1);
        respostaGroup2 = findViewById(R.id.respostaGroup2);
        respostaGroup3 = findViewById(R.id.respostaGroup3);

        radioButtons1 = new RadioButton[]{
                findViewById(R.id.resposta1),
                findViewById(R.id.resposta2),
                findViewById(R.id.resposta3),
                findViewById(R.id.resposta4),
                findViewById(R.id.resposta5)
        };

        radioButtons2 = new RadioButton[]{
                findViewById(R.id.resposta6),
                findViewById(R.id.resposta7),
                findViewById(R.id.resposta8),
                findViewById(R.id.resposta9),
                findViewById(R.id.resposta10)
        };

        radioButtons3 = new RadioButton[]{
                findViewById(R.id.resposta11),
                findViewById(R.id.resposta12),
                findViewById(R.id.resposta13),
                findViewById(R.id.resposta14),
                findViewById(R.id.resposta15)
        };

        startButton.setOnClickListener(view -> iniciarQuiz());
        resetButton.setOnClickListener(view -> reiniciarQuiz());
    }

    private void iniciarQuiz() {
        startButton.setText("Finish");
        startButton.setOnClickListener(view -> finalizarQuiz());
        scrollView.setVisibility(View.VISIBLE);
        carregarQuestao();
    }

    private void finalizarQuiz() {
        verificarRespostas();
        scrollView.setVisibility(View.GONE);
        startButton.setText("Start");
        startButton.setOnClickListener(view -> iniciarQuiz());
        Toast.makeText(this, "Quiz Finalizado! Você acertou: " + respostasCorretas.length, Toast.LENGTH_LONG).show();
    }

    private void carregarQuestao() {
        pergunta1TextView.setText(perguntas[0]);
        pergunta2TextView.setText(perguntas[1]);
        pergunta3TextView.setText(perguntas[2]);

        for (int i = 0; i < radioButtons1.length; i++) {
            radioButtons1[i].setText(respostas[0][i]);
        }

        for (int i = 0; i < radioButtons2.length; i++) {
            radioButtons2[i].setText(respostas[1][i]);
        }

        for (int i = 0; i < radioButtons3.length; i++) {
            radioButtons3[i].setText(respostas[2][i]);
        }
    }

    private void reiniciarQuiz() {
        startButton.setText("Start");
        startButton.setOnClickListener(view -> iniciarQuiz());
        scrollView.setVisibility(View.GONE);
        respostaGroup1.clearCheck();
        respostaGroup2.clearCheck();
        respostaGroup3.clearCheck();
    }

    private void verificarRespostas() {
        int respostasCorretasCount = 0;

        if (respostaGroup1.getCheckedRadioButtonId() == radioButtons1[respostasCorretas[0]].getId()) {
            respostasCorretasCount++;
        }

        if (respostaGroup2.getCheckedRadioButtonId() == radioButtons2[respostasCorretas[1]].getId()) {
            respostasCorretasCount++;
        }

        if (respostaGroup3.getCheckedRadioButtonId() == radioButtons3[respostasCorretas[2]].getId()) {
            respostasCorretasCount++;
        }

        Toast.makeText(this, "Você acertou: " + respostasCorretasCount + " de " + perguntas.length, Toast.LENGTH_LONG).show();
    }
}
